#include <stdint.h>
#include "flash_avl.h"

const avl_bin_hdr_t hdr =
{
    .chip_id    = SMART_RTL8762D,
    .ver        = 0,
    .total_num  = 0,
    .crc16      = 0,
};

const flash_avl_t avl[] =
{
    {
        /* GD25Q64C/GD25Q64E */
        /* size,         manu, device */
        FLASH_BITS_64M,  0xC8, 0x4017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* W25Q128JVPIQ */
        /* size,         manu, device */
        FLASH_BITS_128M, 0xEF, 0x4018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* ZB25VQ32B */
        /* size,         manu, device */
        FLASH_BITS_32M,  0x5E, 0x4016,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* ZB25VQ64A */
        /* size,         manu, device */
        FLASH_BITS_64M,  0x5E, 0x4017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* ZB25VQ128 */
        /* size,         manu, device */
        FLASH_BITS_128M, 0x5E, 0x4018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* P25Q32H */
        /* size,         manu, device */
        FLASH_BITS_32M,  0x85, 0x6016,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* P25Q64H */
        /* size,         manu, device */
        FLASH_BITS_64M,  0x85, 0x6017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* P25Q128L/P25QH128 */
        /* size,         manu, device */
        FLASH_BITS_128M, 0x85, 0x6018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* PY25Q64HA */
        /* size,         manu, device */
        FLASH_BITS_128M, 0x85, 0x2017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,        0,        0,    0,      0}
    },
    {
        /* PY25Q128HA */
        /* size,         manu, device */
        FLASH_BITS_128M, 0x85, 0x2018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* PY25Q256HB */
        /* size,         manu, device */
        FLASH_BITS_256M, 0x85, 0x2019,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,        0x0f,    0xe9,     0,        0xb7, 0x15,   0}
    },
    {
        /* BY25Q64AS */
        /* size,         manu, device */
        FLASH_BITS_64M,  0x68, 0x4017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,        0,        0,    0,      0}
    },
    {
        /* BY25Q128AL */
        /* size,         manu, device */
        FLASH_BITS_128M, 0xE0, 0x6018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* BY25Q128AS */
        /* size,         manu, device */
        FLASH_BITS_128M, 0x68, 0x4018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* BY25Q256FS */
        /* size,         manu, device */
        FLASH_BITS_256M, 0x68, 0x4919,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,        0x0F,    0xe9,     0,        0xb7, 0x15,   0}
    },
    {
        /* W77Q128JV */
        /* size,         manu, device */
        FLASH_BITS_128M, 0xEF, 0x4A18,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,        0,        0,    0,      0}
    },
    {
        /* W25Q64FW */
        /* size,         manu, device */
        FLASH_BITS_64M,  0xEF, 0x6017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,        0,        0,    0,      0}
    },
    {
        /* W25Q128FW */
        /* size,         manu, device */
        FLASH_BITS_128M, 0xEF, 0x6018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,        0,        0,    0,      0}
    },
    {
        /* W25Q256JW-IQ */
        /* size,         manu, device */
        FLASH_BITS_256M, 0xEF, 0x6019,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,         0x0F,    0xe9,      0,     0xb7,  0x15,  0x0}
    },
    {
        /* W25Q256JW-IM */
        /* size,         manu, device */
        FLASH_BITS_256M, 0xEF, 0x8019,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,         0x0F,    0xe9,      0,     0xb7,  0x15,  0x0}
    },
    {
        /* MX25U25645G */
        /* size,         manu, device */
        FLASH_BITS_256M, 0xC2, 0x2539,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x06, 0x6b, 0xeb,  0x38,    0,     0x15,   0,      0,    0,   0,     0,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {11,     10,         0x0F,    0xe9,      0,   0xb7,  0x15,  0x05}
    },
    {
        /* XM25QH32B */
        /* size,        manu, device */
        FLASH_BITS_32M, 0x20, 0x4016,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,        0,        0,     0,     0}
    },
    {
        /* XM25QH64A: Both QE bit and T/B Bit are fake. */
        /* size,        manu, device */
        FLASH_BITS_64M, 0x20, 0x7017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x0C, 0x6b, 0xeb,  0x32, 0x50,     0x09,  0,     0,    0,   0,     0,     0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {9,     8,         0x0F,    0,        0,        0,    0,      0}
    },
    {
        /* XM25QH64C */
        /* size,        manu, device */
        FLASH_BITS_64M, 0x20, 0x4017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* XM25QU64C */
        /* size,        manu, device */
        FLASH_BITS_64M, 0x20, 0x4117,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* XM25QH256C */
        /* size,         manu, device */
        FLASH_BITS_256M, 0x20, 0x4019,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,         0x0F,    0xe9,      0,      0xb7,   0x15,  0x0}
    },
    {
        /* XM25QU256C */
        /* size,         manu, device */
        FLASH_BITS_256M, 0x20, 0x4119,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,         0x0F,    0xe9,      0,      0xb7,   0x15,  0x0}
    },
    {
        /* GD25WQ80E */
        /* size,         manu, device */
        FLASH_BITS_8M,   0xC8, 0x6514,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,    0,    0,    0,    0,     0,    0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,         5,      0x07,       0,      0,        0,    0,     0}
    },
    {
        /* GD25LQ64C/GD25LQ64E */
        /* size,         manu, device */
        FLASH_BITS_64M,  0xC8, 0x6017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0,     0,    0,   0,     0,     0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,        0,        0,    0,      0}
    },
    /* GD25LQ128D, GD25LQ128E, GD25LE128E share the same Flash ID */
    {
        /* GD25Q256E */
        /* size,         manu, device */
        FLASH_BITS_256M, 0xC8, 0x4019,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,        0x0F,    0xe9,     0,        0xb7, 0x35,   0x01}
    },
    {
        /* GD25LQ255E, GD25LE255E share the same Flash ID */
        /* size,         manu, device */
        FLASH_BITS_256M, 0xC8, 0x6019,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0,     0,    0,   0,     0,     0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,         0x0F,    0xe9,      0,      0xb7, 0x35,   0x03}
    },
    {
        /* XT25F08B-S */
        /* size,         manu, device */
        FLASH_BITS_8M,   0x0B, 0x4014,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0,     0,    0,   0,     0,     0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {14,    5,         0x07,    0,        0,        0,    0,      0}
    },
    {
        /* XT25Q64D */
        /* size,         manu, device */
        FLASH_BITS_64M,  0x0B, 0x6017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* XT25Q128D */
        /* size,         manu, device */
        FLASH_BITS_128M, 0x0B, 0x6018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* XT25F256B */
        /* size,         manu, device */
        FLASH_BITS_256M, 0x0B, 0x4019,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {6,     10,        0x0F,    0xe9,     0,        0xb7, 0x35,   0x0}
    },
    {
        /* JY25VQ128A */
        /* size,         manu, device */
        FLASH_BITS_128M, 0x1C, 0x4018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* FM25Q128A */
        /* size,         manu, device */
        FLASH_BITS_128M, 0xA1, 0x4018,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {9,   0x6b,  0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0,     0,     0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
    {
        /* SH25Q64A */
        /* size,         manu, device */
        FLASH_BITS_64M,  0x04, 0x4017,
        /* Basic Cmd
        rd_do, rd_dio, rdsr, wrsr, be64, se,   pwdn_rls, pwdn */
        {0x3b,  0xbb,  0x05, 0x01, 0xd8, 0x20, 0xab,     0xb9},
        /* Advance Cmd
        qe,   rd_qo, rd_qio, pp4, wren_vol, rdsr2, wrsr2, rdcr, hpm, rdsr3, wrsr3, rsvd0 */
        {0x09, 0x6b, 0xeb,  0x32, 0x50,     0x35,  0x31,  0,    0,   0x15,  0x11,  0x0},
        /* Query Info
        tb_oft, bp_all_lv, bp_mask, cmd_ex4b, pkg_info, en4b, rd4bsr, ads_oft */
        {5,     7,         0x07,    0,      0,        0,     0,     0}
    },
};
